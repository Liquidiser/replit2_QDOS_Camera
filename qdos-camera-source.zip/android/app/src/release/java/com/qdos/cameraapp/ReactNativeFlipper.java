package com.qdos.cameraapp;

import android.content.Context;
import com.facebook.react.ReactInstanceManager;

/**
 * Empty implementation of Flipper for release builds
 */
public class ReactNativeFlipper {
  public static void initializeFlipper(Context context, ReactInstanceManager reactInstanceManager) {
    // Do nothing, as we don't want to initialize Flipper in release builds
  }
}